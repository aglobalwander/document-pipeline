"""
This file appears to be unused. Base classes for transformers are likely defined
in doc_processing.embedding.base.
"""