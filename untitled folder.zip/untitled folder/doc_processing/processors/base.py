"""
This file appears to be unused. Base classes for processors are likely defined
in doc_processing.embedding.base.
"""