"""
This file appears to be unused. Base classes for loaders are likely defined
in doc_processing.embedding.base.
"""